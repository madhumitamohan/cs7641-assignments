import numpy as np


def indices_of_k(arr, k):
    """
    Args:
        arr: (N,) numpy VECTOR of integers from 0 to 9
        k: int, scalar between 0 to 9
    Return:
        indices: (M,) numpy VECTOR of indices where the value is matches k

    Given an array of integer values, use np.where or np.argwhere to return
    an array of all of the indices where the value equals k.
    Hint: You may need to index into the output of np.argwhere.
    """
    raise NotImplementedError


def argmax_1d(arr):
    """
    Args:
        arr: (N,) numpy VECTOR of random numbers
    Return:
        arg_max: int, scalar index of the largest number in the array

    Given an array of integer values, use np.argmax to return the index of
    the largest value in the array. If there are duplicate largest values, return the
    first index encountered
    """
    raise NotImplementedError


def mean_rows(arr):
    """
    Args:
        arr: N x M numpy array of random numbers
    Return:
        means: (N,) numpy VECTOR

    Given a two dimensional array, use np.mean and the axis parameter to calculate
    the mean of each row.
    """
    raise NotImplementedError


def sum_squares(arr):
    """
    Args:
        arr: N x M numpy array of random numbers
    Return:
        squared_sums: N x 1 numpy array (NOT vector)

    Given a two dimensional array, use np.square or elementwise squaring to square every
    value in the array. Then, use np.sum, the axis parameter, and the keepdims parameter to
    sum the columns in each row of the squared array and keep the output as a 2 dimensional array.

    Example:
    arr:
    [[1,1,1],
     [2,2,2],
     [3,3,3]]
    squared_sums:
    [[3],
     [12],
     [27]]
    """
    raise NotImplementedError


def fast_manhattan(x, y):
    """
    Args:
        x: N x D numpy array
        y: M x D numpy array
    Return:
        dist: N x M numpy array, where dist[i, j] is the Manhattan distance between
        x[i, :] and y[j, :]
    """
    raise NotImplementedError
